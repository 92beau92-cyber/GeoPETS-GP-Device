# 05 — WORK EXECUTION / GITHUB SAFETY

Use Work mode with cloud browser/computer where available. Ask the user to upload this ZIP to a Work conversation, and give Work permission to access GitHub only when they want it to inspect or change the repo. Connecting a service requires user action. Do not assume access, or claim you deployed if you only generated a ZIP.

Suggested branches: `work/stage-1-responsive-qa`, then `work/stage-2-rpg`, `work/stage-3-cc-ai`, `work/stage-4-homeos-store`, `work/stage-5-release`. Existing GitHub Pages deploys from `main` root; keep main stable until approved.

Release pattern: update code in branch -> tests -> browser screenshots -> compare against checkpoint 036 -> user signoff -> merge -> verify GitHub Actions/Pages -> live device test. If GitHub edit permissions unavailable, produce a ZIP containing the deployable changed files plus instructions and a patch/diff. Never upload the Work handover ZIP itself to the game repository.

Report separately: VERIFIED EXISTING, IMPLEMENTED BUT UNTESTED, TESTED PASS, TESTED FAIL, BLOCKED/NEEDS SERVICE, NOT IMPLEMENTED, REMOVED BY DECISION. Treat external backend, authenticated users, paid assets and store checkout as explicit gated projects.
