# 04 — TEST AND APPROVAL MATRIX

## Current critical failure reproduction (038)
- Player-selection screen should be displayed on initial visit and not skip to GEO CENTRE. Distinguish simple profile picker vs secure login. Do not fake account security.
- GEO CENTRE header should not clip, collide or overlap the clock, G-P Device label, settings icon.
- Main grid labels: 9 buttons legible, full words or intentional accessible short labels; no clipping/overflow at supported widths.
- Party Leader card: companion visible, no intrusive inner scrollbar, no content cut off, bottom GeoPETS/Party/Save Library/Settings controls accessible. Page scrolling policy should be explicit and consistent.
- Regression: all five species, party leader + two reserves, moves/cooldowns/VFX, HP/status, automatic enemy turns, swaps, Leave, capture, rewards, BAG 18 tiles, GeoDEX tile 1, save library 10 slots, JSON import/export and autosave.

## Browser viewport checks
- iPhone portrait small/large (including browser chrome and safe areas), Android portrait, Windows desktop narrow and wide, landscape/rotation, keyboard focus, text zoom and reduced motion.
- Check all device screens, not just GEO CENTRE. Capture overflow warnings and screenshots; automated detection is NOT proof all visuals are correct.
- Check no console errors, no broken images, no unexpected storage resets, refresh persistence, and reliable return navigation.

## Approval gates
- G0 baseline hash, deploy URL and backup recorded.
- G1 stage scope and credit estimate approved.
- G2 changes implemented in isolated branch and diff reviewed.
- G3 automated and visual tests passed; regressions fixed.
- G4 user approves deployment to `main`.
- G5 post-deployment live smoke test and rollback verified.

No green check without evidence. On failure, report defect and fix before starting next stage. Keep protected checkpoint 036 and latest verified production commit.
