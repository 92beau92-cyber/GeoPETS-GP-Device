# 03 — DECISION REGISTER: KNOWN VS MISSING

The review reached 400/400 decisions in the conversation. This does NOT imply all 400 descriptions and individual decisions are retrievable in this package. CSV records what is explicitly known from available conversation context, and marks all other entries UNVERIFIED. Do not silently replace UNVERIFIED with KEEP.

Explicit known: 338–400 were all KEEP; 313–337 all KEEP; 288–312 all KEEP; 263–287 all KEEP; 238–262 all KEEP; 233–237 all KEEP; 228–232 all KEEP. These overlap only by adjacency; range 228–400 is continuously KEEP. 175 ADJUST (Party Leader may discover free resources without asking each time; safety/license checks). 177 ADJUST (free only by default, paid only when user specifies $$$ cap at start; remain within cap).

The summary describes most other 169–227 as largely KEEP but does not provide a full individually verified register. IDs 001–174 are not available as original complete list. Missing original feature titles/descriptions for many items. Only known titles 338–362 are recorded in the CSV. The complete descriptions of 363–400 are NOT in current source; do not invent them. Some user-approved decisions may be known but original wording is not.

Checkpoint 038 user acceptance: 1 FAIL entry; 2 FAIL header; 3 FAIL main action buttons; 4 FAIL companion/navigation fit; 5 UNTESTED game systems. Checkpoint 039 is corrective candidate, pending tests.

## Reconciliation procedure
1. Ask user for full original review export or locate it through available Work conversation context, if authorized.
2. Map exact proposal wording to each ID and preserve original user decision. Record sources.
3. Dedupe implementation work while retaining each numbered decision and traceability.
4. Flag contradictory scopes, dependency blockers, non-static backend requirements, privacy/commerce risks.
5. Obtain approval for resolved ambiguities BEFORE implementing them.
