# 01 — START HERE, CHATGPT WORK

## Mission
Help the user complete the existing GeoPETS G-P Device browser game and its approved 400-improvement review in FIVE CREDIT-CONTROLLED STAGES, eventually producing one cohesive tested public release on GitHub Pages. Preserve gameplay and design. Use Work's supported computer/browser capabilities to inspect, test and (after user approval) update files and GitHub. If any app/permission is unavailable, state the limitation and produce a ready-to-upload artifact rather than pretending it was published.

## Current verified situation
- GitHub repository: https://github.com/92beau92-cyber/GeoPETS-GP-Device (public, `main`). User successfully published an existing game on GitHub Pages.
- Public site: https://92beau92-cyber.github.io/GeoPETS-GP-Device/ ; user showed it displaying the original gold/blue G-P Device with GEO CENTRE, Rune Wolf, Home DECK, Store, S.M.A.R.T AI, HS Shifts, Treasury, Programs, GeoPETS, Party, Save Library and Settings.
- Checkpoint 036 is protected historical original. Checkpoint 037 was a mobile-fit experiment. Checkpoint 038 (first attempt at Stage/Batch 1) failed user acceptance: 4 FAIL, 1 UNTESTED. Checkpoint 039 is a corrective candidate prepared after screenshot review, **NOT YET ACCEPTED**. The user is uploading/testing 039 separately while asking Work to plan/execute full project.
- Specific observed 038 defects: player selection did not appear; GEO CENTRE header and clock overlap/clip; 9 main action labels wrap/clip; main companion screen scrolls internally and device text/navigation is too small. Screenshot included under evidence. Regression of battle/BAG/Party/Save Library remains UNTESTED.
- The 400-item REVIEW is complete; this is NOT 400 features implemented. User approved many KEEP decisions, and known ADJUST details are recorded. The original complete 001–400 descriptions and some decisions are not all present in this handover. Do NOT fabricate missing descriptions/decisions. First seek original review/export where necessary, or maintain explicitly unverified placeholders.

## First action for Work (do not skip)
1. Inspect this ZIP, read all planning documents and inspect game files; identify whether 039 differs from 036/038, and whether the current GitHub `main` matches any supplied checkpoint. Never assume it does.
2. Inspect public website on desktop and mobile viewports; test initial entry, header, controls, companion, battles, Party, BAG, GeoDEX, Save Library, save refresh, settings and navigation. Record screenshots and test evidence.
3. Review checkpoint 039 and the user's latest feedback. If 039 is not yet confirmed, prioritize completing/fixing Stage 1 rather than layering on more features.
4. Recover the complete original 400-improvement list and all decisions if available through this user's Work context or user-provided source. Do not convert missing rows into invented features. Produce a reconciled acceptance matrix with source provenance.
5. Prepare Stage 1 patch in a separate branch/ZIP, run tests, provide preview and exact changed-file summary; seek approval before merging into `main`. Continue through Stages 2–5 with gates.

## Hard constraints
- Preserve the original G-P Device gold-and-blue frame, black inner rounded border, 3-member party, 5 typed species, 9 move buttons, VFX, cooldowns, enemy turns, HP/status, swaps, captures, rewards, BAG/GeoDEX, Save Library (autosave, 10 slots, JSON import/export), artwork and all other verified features.
- NEVER replace with a mockup, screenshot, simplified demo, rewrite or unrelated framework unless user explicitly authorizes.
- Do not expose private data, tokens, credentials or household details in public GitHub Pages. GitHub Pages is STATIC; secure accounts, AI workers, Home OS private data and commerce require separately scoped secure services. A profile chooser is not authentication.
- FREE-ONLY assets/tools by default; no paid resources unless user sets a project $$$ cap at start. For known decision 175, Party Leader can discover free resources without repeated user prompts, subject to safety/license checks. Known decision 177 requires default FREE ONLY and budget cap if paid approved.
- No purchases, public publishing, store transactions, account changes, or main-branch merge without clear user approval. Backups/checkpoints, rollback, evidence, changelogs and regression tests mandatory.
- Do not burn Work usage on repeated screenshots, duplicated research, regenerating entire source or unproductive retries. Stop and ask when blocked.

## Five-stage execution contract
Follow `02_FIVE_STAGE_PLAN.md`. Every stage: audit -> small coherent code bricks -> automated tests -> browser/phone test -> diff and evidence -> approval checkpoint -> merge/deploy only with permission. Reserve Work credits for tasks needing browser/agent; do simple deterministic edits/tests in code where possible. Report estimated credit burden LOW/MED/HIGH (actual credit amounts cannot be guaranteed).

## User-friendly status format after each work session
`Stage X/5 | Brick Y | Verified changes | Tests passed/failed | Files changed | GitHub branch/URL | Outstanding risks | Estimated credits used (if visible) | NEXT APPROVAL REQUIRED`.

## Work opening prompt
"Read START_HERE and the 5-stage plan inside the uploaded GeoPETS Work handover ZIP. Verify the actual GitHub live game and Checkpoint 039 against the preserved Checkpoint 036 source. Reconcile the available 400-decision register without inventing missing entries. Use credits carefully. First finish Stage 1 responsive layout and deliberate entry/login behaviour, show evidence and request my approval before merging. Continue stages 2–5 only through explicit approval gates, preserving gameplay and the G-P Device design."
