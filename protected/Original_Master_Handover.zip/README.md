# GeoPETS — CHATGPT WORK MASTER HANDOVER

**Read `01_START_HERE_WORK.md` first.** This ZIP is a handover for ChatGPT Work, not a deployable website ZIP. Do not upload this entire ZIP to GitHub Pages. The current published site is https://92beau92-cyber.github.io/GeoPETS-GP-Device/ and the source repository is https://github.com/92beau92-cyber/GeoPETS-GP-Device .

Contents: actual game source checkpoints, current corrective build, five-stage plan, known decision record, 400-row tracking CSV, acceptance checklist, source manifest and observed failure screenshot. Do not claim the 400 improvements have been implemented. Work must verify GitHub state before changing it.
