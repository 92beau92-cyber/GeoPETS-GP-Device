# GeoPETS Checkpoint 038 — Batch 1 of 5

Built on the existing Checkpoint 037 game. Upload **index.html** to the repository root, replacing the existing file. Do not upload this ZIP itself.

Changes: explicit local profile chooser on each load (not secure login); reusable responsive CSS for header, Geo Centre, companion area, action grid and bottom buttons; automatic browser layout audit across views (`window.GeoPETSLayoutAudit()` in DevTools). Existing battle and save logic is otherwise retained.

IMPORTANT: This is a LOCAL PROFILE CHOOSER, not account authentication. All profiles still share local saves. Do not store private information on public GitHub Pages.

Batch 1 scope: (1) manual entry, (2) header fit, (3) action label fit, (4) main companion screen layout, (5) cross-screen layout audit. These are targeted fixes, not five specific numbered historical decisions.

Test on iPhone and desktop before accepting. The audit detects issues; it does not guarantee all layouts are correct. Use GitHub commit history to revert if necessary.
